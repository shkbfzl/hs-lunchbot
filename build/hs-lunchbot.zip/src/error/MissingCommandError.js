/**
 * Created by mohamed.kante on 9/19/16.
 */

require('rootpath')();
require('extend-error');

module.exports = Error.extend('MissingCommandError');
