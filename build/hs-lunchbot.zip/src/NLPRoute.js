/**
 * NLP Engine routing file
 *
 */

module.exports = {

    'Hello': [
        "h+i+\\s*",
        "hello\\s*",
        "holla\\s*",
        "Bonjour\\s*"
    ],
    // Add more NLP routes here
}