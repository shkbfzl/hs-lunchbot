/**
 * App default configuration
 */

module.exports = {
    env: "production"
}
