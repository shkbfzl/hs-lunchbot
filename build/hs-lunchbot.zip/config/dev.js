/**
 * App default configuration
 */

module.exports = {
    env: "development"
}
